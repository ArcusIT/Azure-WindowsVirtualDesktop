Configuration ADDomain_NewForest_Config
{
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $domainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc

    node 'localhost'
    {
        WindowsFeature 'ADDS'
        {
            Name   = 'AD-Domain-Services'
            Ensure = 'Present'
        }
        
        WindowsFeature 'RSATTools'
        {
            Name   = 'RSAT-ADDS-Tools'
            Ensure = 'Present'
        }
        
        WindowsFeature 'RSATPS'
        {
            Name   = 'RSAT-AD-PowerShell'
            Ensure = 'Present'
        }

        ADDomain $domainName
        {
            DomainName                    = $domainName
            Credential                    = $Credential
            SafemodeAdministratorPassword = $Credential
            ForestMode                    = 'WinThreshold'
        }
    }
}

Configuration ADDomain_AddDomainControllerToDomain_Config
{
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $domainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc

    node localhost
    {
        WindowsFeature 'InstallADDomainServicesFeature'
        {
            Ensure = 'Present'
            Name   = 'AD-Domain-Services'
        }

        WindowsFeature 'RSATTools'
        {
            Name   = 'RSAT-ADDS-Tools'
            Ensure = 'Present'
        }

        WindowsFeature 'RSATADPowerShell'
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-PowerShell'

            DependsOn = '[WindowsFeature]InstallADDomainServicesFeature'
        }

        WaitForADDomain 'WaitForestAvailability'
        {
            DomainName = $domainName
            Credential = $Credential

            DependsOn  = '[WindowsFeature]RSATADPowerShell'
        }

        ADDomainController 'DomainControllerMinimal'
        {
            DomainName                    = $domainName
            Credential                    = $Credential
            SafeModeAdministratorPassword = $Credential

            DependsOn                     = '[WaitForADDomain]WaitForestAvailability'
        }
    }
}