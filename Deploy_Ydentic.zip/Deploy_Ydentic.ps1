<#PSScriptInfo
.VERSION 1.0.1
.GUID e7ed876c-7a6b-46d7-bb89-8288680c1691
.AUTHOR DSC Community
.COMPANYNAME DSC Community
.COPYRIGHT DSC Community contributors. All rights reserved.
.TAGS DSCConfiguration
.LICENSEURI https://github.com/dsccommunity/ActiveDirectoryDsc/blob/main/LICENSE
.PROJECTURI https://github.com/dsccommunity/ActiveDirectoryDsc
.ICONURI https://dsccommunity.org/images/DSC_Logo_300p.png
.RELEASENOTES
Updated author, copyright notice, and URLs.
#>

#Requires -Module ActiveDirectoryDsc

<#
    .DESCRIPTION
        This configuration will add an Active Directory organizational unit to the domain.
#>
Configuration ADOrganizationalUnit_CreateADOU_Config
{
    Import-DscResource -Module ActiveDirectoryDsc

    Node localhost
    {
        ADOrganizationalUnit 'Accounts'
        {
            Name                            = "Accounts"
            Path                            = "dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Groups'
        {
            Name                            = "Groups"
            Path                            = "dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Mail'
        {
            Name                            = "Mail"
            Path                            = "dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Servers'
        {
            Name                            = "Servers"
            Path                            = "dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Deleted'
        {
            Name                            = "Deleted"
            Path                            = "ou=Accounts, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Service'
        {
            Name                            = "Service"
            Path                            = "ou=Accounts, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Users'
        {
            Name                            = "Users"
            Path                            = "ou=Accounts, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'External'
        {
            Name                            = "External"
            Path                            = "ou=Accounts, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Applications'
        {
            Name                            = "Applications"
            Path                            = "ou=Groups, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Control'
        {
            Name                            = "Control"
            Path                            = "ou=Groups, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Roles'
        {
            Name                            = "Roles"
            Path                            = "ou=Groups, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Security'
        {
            Name                            = "Security"
            Path                            = "ou=Groups, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Contacts'
        {
            Name                            = "Contacts"
            Path                            = "ou=Mail, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Distribution Groups'
        {
            Name                            = "Distribution Groups"
            Path                            = "ou=Mail, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Resource Mailbox'
        {
            Name                            = "Resource Mailbox"
            Path                            = "ou=Mail, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }

        ADOrganizationalUnit 'Shared Mailbox'
        {
            Name                            = "Shared Mailbox"
            Path                            = "ou=Mail, dc=test, dc=nl"
            ProtectedFromAccidentalDeletion = $true
            Description                     = ""
            Ensure                          = 'Present'
        }
    }
}